import React, { createContext, useContext, useState, useEffect } from 'react';
import { AITool, AIPrompt, AICategoryId, PromptCategoryId, PricingModel } from '../types';
import { INITIAL_AI_TOOLS, INITIAL_PROMPTS } from '../data/initialData';

interface ToastMessage {
  id: number;
  message: string;
  type: 'success' | 'info' | 'error';
}

interface AppContextType {
  // Navigation & filters
  activeTab: 'tools' | 'prompts' | 'favorites' | 'about';
  setActiveTab: (tab: 'tools' | 'prompts' | 'favorites' | 'about') => void;
  selectedCategory: AICategoryId | 'all';
  setSelectedCategory: (cat: AICategoryId | 'all') => void;
  selectedPromptCategory: PromptCategoryId | 'all';
  setSelectedPromptCategory: (cat: PromptCategoryId | 'all') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  pricingFilter: PricingModel | 'all';
  setPricingFilter: (filter: PricingModel | 'all') => void;

  // Tools & Prompts
  tools: AITool[];
  prompts: AIPrompt[];
  filteredTools: AITool[];
  filteredPrompts: AIPrompt[];

  // Favorites
  favoriteToolIds: string[];
  favoritePromptIds: string[];
  toggleFavoriteTool: (id: string) => void;
  toggleFavoritePrompt: (id: string) => void;
  isToolFavorite: (id: string) => boolean;
  isPromptFavorite: (id: string) => boolean;

  // CRUD for tools and prompts
  addCustomTool: (tool: Omit<AITool, 'id' | 'isCustom'>) => void;
  updateTool: (id: string, updated: Partial<AITool>) => void;
  deleteTool: (id: string) => void;
  addCustomPrompt: (prompt: Omit<AIPrompt, 'id' | 'isCustom'>) => void;
  deletePrompt: (id: string) => void;
  resetToDefaults: () => void;
  exportDataAsJson: () => string;
  importDataFromJson: (jsonStr: string) => boolean;

  // Tool Detail modal
  selectedToolDetail: AITool | null;
  setSelectedToolDetail: (tool: AITool | null) => void;

  // AdMob preview toggle
  admobVisible: boolean;
  setAdmobVisible: (visible: boolean | ((prev: boolean) => boolean)) => void;

  // Toast
  toast: ToastMessage | null;
  showToast: (message: string, type?: 'success' | 'info' | 'error') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEYS = {
  FAVORITE_TOOLS: 'masry_ai_fav_tools',
  FAVORITE_PROMPTS: 'masry_ai_fav_prompts',
  CUSTOM_TOOLS: 'masry_ai_custom_tools',
  CUSTOM_PROMPTS: 'masry_ai_custom_prompts',
  ADMOB_PREVIEW: 'masry_ai_admob_visible',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<'tools' | 'prompts' | 'favorites' | 'about'>('tools');
  const [selectedCategory, setSelectedCategory] = useState<AICategoryId | 'all'>('all');
  const [selectedPromptCategory, setSelectedPromptCategory] = useState<PromptCategoryId | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [pricingFilter, setPricingFilter] = useState<PricingModel | 'all'>('all');

  // Favorites from local storage
  const [favoriteToolIds, setFavoriteToolIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.FAVORITE_TOOLS);
      return saved ? JSON.parse(saved) : ['midjourney', 'suno-ai', 'claude-ai', 'cursor-ai'];
    } catch {
      return ['midjourney', 'suno-ai', 'claude-ai', 'cursor-ai'];
    }
  });

  const [favoritePromptIds, setFavoritePromptIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.FAVORITE_PROMPTS);
      return saved ? JSON.parse(saved) : ['prompt-egyptian-copy', 'prompt-suno-egyptian-song'];
    } catch {
      return ['prompt-egyptian-copy', 'prompt-suno-egyptian-song'];
    }
  });

  // Custom Tools from local storage
  const [customTools, setCustomTools] = useState<AITool[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.CUSTOM_TOOLS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Custom Prompts from local storage
  const [customPrompts, setCustomPrompts] = useState<AIPrompt[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.CUSTOM_PROMPTS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [selectedToolDetail, setSelectedToolDetail] = useState<AITool | null>(null);
  const [admobVisible, setAdmobVisible] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.ADMOB_PREVIEW);
      return saved !== null ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  const [toast, setToast] = useState<ToastMessage | null>(null);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.FAVORITE_TOOLS, JSON.stringify(favoriteToolIds));
    } catch (e) {
      console.error(e);
    }
  }, [favoriteToolIds]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.FAVORITE_PROMPTS, JSON.stringify(favoritePromptIds));
    } catch (e) {
      console.error(e);
    }
  }, [favoritePromptIds]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.CUSTOM_TOOLS, JSON.stringify(customTools));
    } catch (e) {
      console.error(e);
    }
  }, [customTools]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.CUSTOM_PROMPTS, JSON.stringify(customPrompts));
    } catch (e) {
      console.error(e);
    }
  }, [customPrompts]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.ADMOB_PREVIEW, JSON.stringify(admobVisible));
    } catch (e) {
      console.error(e);
    }
  }, [admobVisible]);

  // Combined tools and prompts
  const allTools = [...INITIAL_AI_TOOLS, ...customTools];
  const allPrompts = [...INITIAL_PROMPTS, ...customPrompts];

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Date.now();
    setToast({ id, message, type });
    setTimeout(() => {
      setToast((current) => (current?.id === id ? null : current));
    }, 3200);
  };

  const toggleFavoriteTool = (id: string) => {
    setFavoriteToolIds((prev) => {
      const isFav = prev.includes(id);
      const next = isFav ? prev.filter((item) => item !== id) : [...prev, id];
      showToast(isFav ? 'تم الحذف من المفضلة' : 'تمت الإضافة إلى المفضلة ❤️', isFav ? 'info' : 'success');
      return next;
    });
  };

  const toggleFavoritePrompt = (id: string) => {
    setFavoritePromptIds((prev) => {
      const isFav = prev.includes(id);
      const next = isFav ? prev.filter((item) => item !== id) : [...prev, id];
      showToast(isFav ? 'تم حذف البرومبت من المفضلة' : 'تم حفظ البرومبت في المفضلة ⭐', isFav ? 'info' : 'success');
      return next;
    });
  };

  const isToolFavorite = (id: string) => favoriteToolIds.includes(id);
  const isPromptFavorite = (id: string) => favoritePromptIds.includes(id);

  const addCustomTool = (toolData: Omit<AITool, 'id' | 'isCustom'>) => {
    const newTool: AITool = {
      ...toolData,
      id: `custom-tool-${Date.now()}`,
      isCustom: true,
      reviewCount: 1,
      isVerified: true,
    };
    setCustomTools((prev) => [newTool, ...prev]);
    showToast(`تمت إضافة أداة «${newTool.arabicName || newTool.name}» بنجاح!`, 'success');
  };

  const updateTool = (id: string, updated: Partial<AITool>) => {
    setCustomTools((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );
    showToast('تم تحديث بيانات الأداة بنجاح', 'success');
  };

  const deleteTool = (id: string) => {
    setCustomTools((prev) => prev.filter((item) => item.id !== id));
    setFavoriteToolIds((prev) => prev.filter((item) => item !== id));
    showToast('تم حذف الأداة من دليلك', 'info');
  };

  const addCustomPrompt = (promptData: Omit<AIPrompt, 'id' | 'isCustom'>) => {
    const newPrompt: AIPrompt = {
      ...promptData,
      id: `custom-prompt-${Date.now()}`,
      isCustom: true,
    };
    setCustomPrompts((prev) => [newPrompt, ...prev]);
    showToast(`تمت إضافة البرومبت «${newPrompt.title}» بنجاح!`, 'success');
  };

  const deletePrompt = (id: string) => {
    setCustomPrompts((prev) => prev.filter((item) => item.id !== id));
    setFavoritePromptIds((prev) => prev.filter((item) => item !== id));
    showToast('تم حذف البرومبت', 'info');
  };

  const resetToDefaults = () => {
    localStorage.removeItem(LOCAL_STORAGE_KEYS.FAVORITE_TOOLS);
    localStorage.removeItem(LOCAL_STORAGE_KEYS.FAVORITE_PROMPTS);
    localStorage.removeItem(LOCAL_STORAGE_KEYS.CUSTOM_TOOLS);
    localStorage.removeItem(LOCAL_STORAGE_KEYS.CUSTOM_PROMPTS);
    setFavoriteToolIds(['midjourney', 'suno-ai', 'claude-ai', 'cursor-ai']);
    setFavoritePromptIds(['prompt-egyptian-copy', 'prompt-suno-egyptian-song']);
    setCustomTools([]);
    setCustomPrompts([]);
    showToast('تمت استعادة إعدادات وقاعدة بيانات التطبيق الأصلية', 'info');
  };

  const exportDataAsJson = () => {
    const exportObject = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      favoriteToolIds,
      favoritePromptIds,
      customTools,
      customPrompts,
    };
    return JSON.stringify(exportObject, null, 2);
  };

  const importDataFromJson = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (Array.isArray(data.favoriteToolIds)) setFavoriteToolIds(data.favoriteToolIds);
      if (Array.isArray(data.favoritePromptIds)) setFavoritePromptIds(data.favoritePromptIds);
      if (Array.isArray(data.customTools)) setCustomTools(data.customTools);
      if (Array.isArray(data.customPrompts)) setCustomPrompts(data.customPrompts);
      showToast('تم استيراد بياناتك ونسختك الاحتياطية بنجاح!', 'success');
      return true;
    } catch {
      showToast('خطأ في صيغة ملف JSON المستورد', 'error');
      return false;
    }
  };

  // Filtered lists
  const filteredTools = allTools.filter((tool) => {
    // If in favorites tab, only show favorites
    if (activeTab === 'favorites' && !favoriteToolIds.includes(tool.id)) {
      return false;
    }

    // Category filter
    if (selectedCategory !== 'all' && tool.category !== selectedCategory) {
      return false;
    }

    // Pricing filter
    if (pricingFilter !== 'all' && tool.pricing !== pricingFilter) {
      return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      const inName = tool.name.toLowerCase().includes(query);
      const inArabicName = tool.arabicName.toLowerCase().includes(query);
      const inDesc = tool.description.toLowerCase().includes(query);
      const inCompany = tool.company.toLowerCase().includes(query);
      const inTags = tool.tags.some((tag) => tag.toLowerCase().includes(query));
      const inTips = tool.tipsForArabs.toLowerCase().includes(query);
      return inName || inArabicName || inDesc || inCompany || inTags || inTips;
    }

    return true;
  });

  const filteredPrompts = allPrompts.filter((prompt) => {
    if (activeTab === 'favorites' && !favoritePromptIds.includes(prompt.id)) {
      return false;
    }

    if (selectedPromptCategory !== 'all' && prompt.category !== selectedPromptCategory) {
      return false;
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      const inTitle = prompt.title.toLowerCase().includes(query);
      const inContent = prompt.promptText.toLowerCase().includes(query);
      const inTool = prompt.recommendedTool.toLowerCase().includes(query);
      const inTags = prompt.tags.some((t) => t.toLowerCase().includes(query));
      return inTitle || inContent || inTool || inTags;
    }

    return true;
  });

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        selectedCategory,
        setSelectedCategory,
        selectedPromptCategory,
        setSelectedPromptCategory,
        searchQuery,
        setSearchQuery,
        pricingFilter,
        setPricingFilter,
        tools: allTools,
        prompts: allPrompts,
        filteredTools,
        filteredPrompts,
        favoriteToolIds,
        favoritePromptIds,
        toggleFavoriteTool,
        toggleFavoritePrompt,
        isToolFavorite,
        isPromptFavorite,
        addCustomTool,
        updateTool,
        deleteTool,
        addCustomPrompt,
        deletePrompt,
        resetToDefaults,
        exportDataAsJson,
        importDataFromJson,
        selectedToolDetail,
        setSelectedToolDetail,
        admobVisible,
        setAdmobVisible,
        toast,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
