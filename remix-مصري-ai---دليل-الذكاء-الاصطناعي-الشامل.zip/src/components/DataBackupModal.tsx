import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Download, 
  Upload, 
  RotateCcw, 
  Copy, 
  Check, 
  Eye, 
  EyeOff, 
  ShieldAlert, 
  FileJson
} from 'lucide-react';

interface DataBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DataBackupModal: React.FC<DataBackupModalProps> = ({ isOpen, onClose }) => {
  const { 
    exportDataAsJson, 
    importDataFromJson, 
    resetToDefaults, 
    showToast,
    admobVisible,
    setAdmobVisible,
    favoriteToolIds,
    favoritePromptIds,
    tools
  } = useApp();

  const [importText, setImportText] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleExportDownload = () => {
    const jsonStr = exportDataAsJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `masry-ai-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    showToast('تم تحميل ملف النسخة الاحتياطية بنجاح!', 'success');
  };

  const handleCopyJson = () => {
    const jsonStr = exportDataAsJson();
    navigator.clipboard.writeText(jsonStr);
    setCopied(true);
    showToast('تم نسخ كود النسخة الاحتياطية JSON للحافظة', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleImport = () => {
    if (!importText.trim()) {
      showToast('يرجى لصق كود JSON للاستيراد أولاً', 'error');
      return;
    }
    const success = importDataFromJson(importText.trim());
    if (success) {
      setImportText('');
      onClose();
    }
  };

  const handleReset = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في استعادة الإعدادات الأولية؟ سيتم مسح المفضلة والأدوات المخصصة.')) {
      resetToDefaults();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl bg-[#0b1122] border border-blue-500/30 p-6 sm:p-7 shadow-2xl text-right"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-2">
          <FileJson className="w-6 h-6 text-blue-400" />
          <h2 className="text-xl font-bold text-white">
            إدارة البيانات والنسخ الاحتياطي
          </h2>
        </div>
        <p className="text-xs text-slate-400 mb-6">
          بياناتك ومفضلاتك وأدواتك المخصصة تُحفظ محلياً على متصفحك. يمكنك تصديرها أو نقلها لجهاز آخر في أي وقت.
        </p>

        {/* Section 1: AdMob Display Control */}
        <div className="p-4 rounded-2xl bg-[#080e1c] border border-slate-800 mb-6">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h4 className="text-sm font-bold text-white mb-0.5">
                مساحات إعلانات Google AdMob
              </h4>
              <p className="text-xs text-slate-400">
                إظهار أو إخفاء حيز الإعلانات التجريبية في الصفحة
              </p>
            </div>

            <button
              onClick={() => setAdmobVisible((prev) => !prev)}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                admobVisible
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {admobVisible ? (
                <>
                  <Eye className="w-4 h-4" />
                  <span>ظاهر</span>
                </>
              ) : (
                <>
                  <EyeOff className="w-4 h-4" />
                  <span>مخفي</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Section 2: Export Data */}
        <div className="p-4 rounded-2xl bg-[#080e1c] border border-slate-800 mb-6">
          <h4 className="text-sm font-bold text-white mb-2">
            تصدير نسخة احتياطية (Export)
          </h4>
          <p className="text-xs text-slate-400 mb-4">
            تحميل ملف يحتوي على {favoriteToolIds.length} أداة مفضلة، {favoritePromptIds.length} برومبت محفوظ، وأي أدوات قمت بإضافتها.
          </p>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={handleExportDownload}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-blue-600 hover:bg-blue-500 text-white transition-colors cursor-pointer shadow-md"
            >
              <Download className="w-4 h-4" />
              <span>تحميل ملف JSON</span>
            </button>

            <button
              onClick={handleCopyJson}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ كود JSON'}</span>
            </button>
          </div>
        </div>

        {/* Section 3: Import Data */}
        <div className="p-4 rounded-2xl bg-[#080e1c] border border-slate-800 mb-6">
          <h4 className="text-sm font-bold text-white mb-2">
            استيراد نسخة سابقة (Import)
          </h4>
          <textarea
            rows={3}
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            placeholder="الصق محتوى ملف JSON هنا..."
            className="w-full bg-[#050811] border border-slate-800 rounded-xl p-3 text-white text-xs font-mono focus:border-blue-500 outline-none resize-none mb-3"
            dir="ltr"
          />

          <button
            onClick={handleImport}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-colors cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>استيراد وتطبيق البيانات</span>
          </button>
        </div>

        {/* Section 4: Reset to defaults */}
        <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-900/40 flex items-center justify-between gap-3">
          <div>
            <h4 className="text-sm font-bold text-rose-300 mb-0.5">
              استعادة الإعدادات المصنعية
            </h4>
            <p className="text-xs text-slate-400">
              إعادة تعيين قاعدة البيانات وإلغاء التخصيصات
            </p>
          </div>

          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-rose-600/30 hover:bg-rose-600 text-rose-200 hover:text-white border border-rose-500/30 transition-colors cursor-pointer shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>استعادة</span>
          </button>
        </div>

      </div>
    </div>
  );
};
