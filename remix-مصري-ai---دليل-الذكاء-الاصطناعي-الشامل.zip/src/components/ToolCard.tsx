import React from 'react';
import { AITool } from '../types';
import { useApp } from '../context/AppContext';
import { 
  ExternalLink, 
  Heart, 
  Share2, 
  Info, 
  Star, 
  Sparkles, 
  CheckCircle2, 
  Trash2, 
  Edit3,
  Image as ImageIcon,
  Video,
  Music,
  Mic,
  PenTool,
  Languages,
  Code2,
  MessageSquareText
} from 'lucide-react';

interface ToolCardProps {
  tool: AITool;
  onEdit?: (tool: AITool) => void;
}

export const ToolCard: React.FC<ToolCardProps> = ({ tool, onEdit }) => {
  const { 
    isToolFavorite, 
    toggleFavoriteTool, 
    setSelectedToolDetail, 
    showToast,
    deleteTool 
  } = useApp();

  const isFav = isToolFavorite(tool.id);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'image': return <ImageIcon className="w-5 h-5 text-blue-400" />;
      case 'video': return <Video className="w-5 h-5 text-purple-400" />;
      case 'music': return <Music className="w-5 h-5 text-amber-400" />;
      case 'audio': return <Mic className="w-5 h-5 text-emerald-400" />;
      case 'writing': return <PenTool className="w-5 h-5 text-indigo-400" />;
      case 'translation': return <Languages className="w-5 h-5 text-sky-400" />;
      case 'code': return <Code2 className="w-5 h-5 text-violet-400" />;
      case 'chat': return <MessageSquareText className="w-5 h-5 text-rose-400" />;
      default: return <Sparkles className="w-5 h-5 text-blue-400" />;
    }
  };

  const getPricingBadge = (pricing: string) => {
    switch (pricing) {
      case 'free':
        return (
          <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/25">
            مجاني 100%
          </span>
        );
      case 'freemium':
        return (
          <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-blue-500/15 text-blue-300 border border-blue-500/25">
            مجاني جزئياً
          </span>
        );
      case 'trial':
        return (
          <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-300 border border-amber-500/25">
            تجربة مجانية
          </span>
        );
      case 'paid':
        return (
          <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-purple-500/15 text-purple-300 border border-purple-500/25">
            اشتراك مدفوع
          </span>
        );
      default:
        return null;
    }
  };

  const handleCopyLink = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(tool.url);
    showToast(`تم نسخ رابط ${tool.arabicName || tool.name} المباشر للحافظة!`, 'success');
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm(`هل أنت متأكد من حذف «${tool.arabicName || tool.name}»؟`)) {
      deleteTool(tool.id);
    }
  };

  return (
    <div 
      className="group relative flex flex-col justify-between rounded-2xl bg-[#0c1324] border border-slate-800/80 hover:border-blue-500/40 p-5 transition-all duration-300 hover:shadow-xl hover:shadow-blue-950/30 hover:-translate-y-0.5"
    >
      <div>
        {/* Top bar inside card: Icon, Title, Favorite & Share buttons */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700/60 flex items-center justify-center shrink-0 shadow-inner group-hover:border-blue-500/40 transition-colors">
              {getCategoryIcon(tool.category)}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base sm:text-lg text-white group-hover:text-blue-300 transition-colors">
                  {tool.arabicName}
                </h3>
                {tool.isVerified && (
                  <span title="أداة معتمدة برابط رسمي">
                    <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                  </span>
                )}
              </div>
              <p className="text-xs font-mono text-slate-400">
                {tool.name} · <span className="text-slate-500">{tool.company}</span>
              </p>
            </div>
          </div>

          {/* Action buttons (Fav, Share, Custom delete) */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={() => toggleFavoriteTool(tool.id)}
              className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
              title={isFav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
              aria-label="المفضلة"
            >
              <Heart className={`w-4 h-4 ${isFav ? 'text-rose-500 fill-rose-500' : ''}`} />
            </button>

            <button
              onClick={handleCopyLink}
              className="p-2 rounded-lg text-slate-400 hover:text-blue-400 hover:bg-slate-800 transition-colors cursor-pointer"
              title="نسخ الرابط الرسمي"
              aria-label="نسخ الرابط"
            >
              <Share2 className="w-4 h-4" />
            </button>

            {tool.isCustom && (
              <>
                {onEdit && (
                  <button
                    onClick={() => onEdit(tool)}
                    className="p-2 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-slate-800 transition-colors"
                    title="تعديل الأداة"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={handleDelete}
                  className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                  title="حذف الأداة المخصصة"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Badges / Metadata row */}
        <div className="flex flex-wrap items-center gap-2 mb-3">
          {getPricingBadge(tool.pricing)}
          {tool.badge && (
            <span className="text-xs px-2 py-0.5 rounded-md bg-purple-500/15 text-purple-300 border border-purple-500/25 font-medium">
              {tool.badge}
            </span>
          )}
          <div className="flex items-center gap-1 text-xs text-amber-400 font-mono">
            <Star className="w-3.5 h-3.5 fill-amber-400" />
            <span>{tool.rating.toFixed(1)}</span>
            <span className="text-slate-500 font-sans">({tool.reviewCount.toLocaleString('ar-EG')})</span>
          </div>
        </div>

        {/* Description */}
        <p className="text-sm text-slate-300 leading-relaxed line-clamp-3 mb-4">
          {tool.description}
        </p>

        {/* Egyptian / Arab Pro Tip Callout Box */}
        {tool.tipsForArabs && (
          <div className="mb-4 p-3 rounded-xl bg-[#090f1e] border border-blue-900/30 text-xs text-slate-300 leading-normal">
            <div className="flex items-center gap-1.5 text-blue-400 font-semibold mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>نصيحة الاستخدام في مصر والعالم العربي:</span>
            </div>
            <p className="text-slate-400 line-clamp-2">
              {tool.tipsForArabs}
            </p>
          </div>
        )}

        {/* Tags */}
        <div className="flex flex-wrap items-center gap-1.5 mb-5 text-[11px] text-slate-400">
          {tool.tags.slice(0, 3).map((tag, idx) => (
            <span 
              key={idx}
              className="bg-slate-800/70 px-2 py-0.5 rounded text-slate-300 border border-slate-700/40"
            >
              #{tag}
            </span>
          ))}
          {tool.tags.length > 3 && (
            <span className="text-slate-500 font-mono">+{tool.tags.length - 3}</span>
          )}
        </div>
      </div>

      {/* Card Footer Actions */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
        <button
          onClick={() => setSelectedToolDetail(tool)}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors cursor-pointer"
        >
          <Info className="w-3.5 h-3.5 text-blue-400" />
          <span>شرح وتفاصيل</span>
        </button>

        {/* Direct Link Button */}
        <a
          href={tool.url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-md shadow-blue-900/30 transition-all cursor-pointer whitespace-nowrap group-hover:scale-[1.02]"
        >
          <span>فتح الأداة</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
};
