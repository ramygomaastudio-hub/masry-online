import React, { useState } from 'react';
import { AIPrompt } from '../types';
import { useApp } from '../context/AppContext';
import { 
  Copy, 
  Check, 
  Heart, 
  Sparkles, 
  BookOpen, 
  Layers, 
  Wrench,
  Trash2
} from 'lucide-react';

interface PromptCardProps {
  prompt: AIPrompt;
}

export const PromptCard: React.FC<PromptCardProps> = ({ prompt }) => {
  const { isPromptFavorite, toggleFavoritePrompt, showToast, deletePrompt, setSelectedCategory, setActiveTab } = useApp();
  const [copied, setCopied] = useState(false);

  const isFav = isPromptFavorite(prompt.id);

  const handleCopy = () => {
    navigator.clipboard.writeText(prompt.promptText);
    setCopied(true);
    showToast('تم نسخ البرومبت بنجاح! جاهز للصق في الأداة ⭐', 'success');
    setTimeout(() => setCopied(false), 2400);
  };

  const handleDelete = () => {
    if (window.confirm(`هل أنت متأكد من حذف برومبت «${prompt.title}»؟`)) {
      deletePrompt(prompt.id);
    }
  };

  // Function to highlight variables like [variable]
  const renderFormattedPrompt = (text: string) => {
    const parts = text.split(/(\[[^\]]+\])/g);
    return parts.map((part, index) => {
      if (part.startsWith('[') && part.endsWith(']')) {
        return (
          <span 
            key={index}
            className="inline-block px-1.5 py-0.5 mx-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold"
          >
            {part}
          </span>
        );
      }
      return <span key={index}>{part}</span>;
    });
  };

  const getDifficultyBadge = (diff: string) => {
    switch (diff) {
      case 'مبتدئ':
        return <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300">مبتدئ</span>;
      case 'متوسط':
        return <span className="text-[11px] px-2 py-0.5 rounded bg-blue-500/15 text-blue-300">متوسط</span>;
      case 'متقدم':
        return <span className="text-[11px] px-2 py-0.5 rounded bg-purple-500/15 text-purple-300">متقدم</span>;
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col justify-between rounded-2xl bg-[#0c1324] border border-slate-800 hover:border-purple-500/40 p-5 transition-all duration-300 hover:shadow-xl hover:shadow-purple-950/20">
      <div>
        {/* Top bar: Category, Tool, Difficulty, Actions */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg bg-purple-500/15 text-purple-300 border border-purple-500/25">
              <Sparkles className="w-3 h-3" />
              <span>{prompt.recommendedTool}</span>
            </span>
            {getDifficultyBadge(prompt.difficulty)}
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => toggleFavoritePrompt(prompt.id)}
              className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title={isFav ? 'إزالة من المفضلة' : 'حفظ في المفضلة'}
              aria-label="المفضلة"
            >
              <Heart className={`w-4 h-4 ${isFav ? 'text-rose-500 fill-rose-500' : ''}`} />
            </button>

            {prompt.isCustom && (
              <button
                onClick={handleDelete}
                className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                title="حذف البرومبت"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Prompt Title */}
        <h3 className="font-bold text-base sm:text-lg text-white mb-2 leading-snug">
          {prompt.title}
        </h3>

        {/* Explanation */}
        <p className="text-xs text-slate-400 mb-3 leading-relaxed">
          {prompt.explanation}
        </p>

        {/* Prompt Content Preview Box */}
        <div className="relative mb-4 p-3.5 rounded-xl bg-[#070b16] border border-slate-800 text-xs text-slate-200 leading-relaxed font-sans max-h-48 overflow-y-auto scrollbar-thin select-all">
          <div className="whitespace-pre-wrap">
            {renderFormattedPrompt(prompt.promptText)}
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap items-center gap-1.5 mb-4 text-[11px] text-slate-400">
          {prompt.tags.map((tag, idx) => (
            <span key={idx} className="bg-slate-800/80 px-2 py-0.5 rounded text-slate-300">
              #{tag}
            </span>
          ))}
        </div>
      </div>

      {/* Footer Copy CTA Button */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3">
        <span className="text-xs text-slate-400">
          استبدل المتغيرات المظللة <span className="text-amber-400 font-semibold">[بين أقواس]</span> ببياناتك
        </span>

        <button
          onClick={handleCopy}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap active:scale-95 shadow-md ${
            copied
              ? 'bg-emerald-600 text-white shadow-emerald-900/30'
              : 'bg-purple-600 hover:bg-purple-500 text-white shadow-purple-900/30'
          }`}
        >
          {copied ? (
            <>
              <Check className="w-4 h-4" />
              <span>تم النسخ!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span>نسخ البرومبت</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
