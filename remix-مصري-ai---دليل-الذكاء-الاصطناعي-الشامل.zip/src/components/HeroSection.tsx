import React, { useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Search, X, Sparkles, Compass, ShieldCheck, Zap } from 'lucide-react';
import { AI_CATEGORIES } from '../data/initialData';

export const HeroSection: React.FC = () => {
  const { 
    searchQuery, 
    setSearchQuery, 
    activeTab, 
    setActiveTab, 
    selectedCategory, 
    setSelectedCategory,
    tools,
    prompts
  } = useApp();
  
  const searchInputRef = useRef<HTMLInputElement>(null);

  const clearSearch = () => {
    setSearchQuery('');
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };

  return (
    <section className="relative overflow-hidden pt-8 pb-10 md:pt-14 md:pb-14 border-b border-slate-800/60 bg-gradient-to-b from-[#0a1022] via-[#070b16] to-[#070b16]">
      {/* Background glowing orbs */}
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -top-24 right-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl opacity-70" 
      />
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute top-12 left-1/4 w-80 h-80 bg-purple-600/12 rounded-full blur-3xl opacity-60" 
      />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 text-center">
        
        {/* Subtle kicker badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950/60 border border-blue-500/25 text-blue-300 text-xs font-medium mb-5 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-blue-400" />
          <span>الدليل التقني الموثق لأدوات الذكاء الاصطناعي 2026</span>
          <span className="text-slate-500">·</span>
          <span className="text-emerald-400">روابط حقيقية 100%</span>
        </div>

        {/* Hero Title */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-tight sm:leading-snug md:leading-normal mb-4" style={{ textWrap: 'balance' }}>
          دليلك المصري لاكتشاف أقوى <br className="hidden sm:inline" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-violet-400">
            أدوات الذكاء الاصطناعي والبرومبتات
          </span>
        </h1>

        {/* Hero Subtitle */}
        <p className="max-w-2xl mx-auto text-slate-300 text-sm sm:text-base leading-relaxed mb-8">
          منصة متخصصة تجمع لك أفضل أدوات توليد الصور، الفيديو، الأغاني، الصوت، والكتابة والبرمجة مع نصائح عملية للاستخدام من مصر والعالم العربي ومكتبة برومبتات جاهزة للنسخ.
        </p>

        {/* Real-Time Search Bar */}
        <div className="max-w-2xl mx-auto mb-7">
          <div className="relative flex items-center bg-[#0d152a] rounded-2xl border border-blue-500/30 shadow-xl shadow-black/40 focus-within:border-blue-400 focus-within:ring-2 focus-within:ring-blue-500/20 transition-all p-1.5 sm:p-2">
            <div className="pr-3 pl-2 text-blue-400 flex items-center justify-center">
              <Search className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>

            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن أداة (ميدجورني، سونو، كلود...) أو برومبت أو كلمة مفتاحية..."
              className="w-full bg-transparent text-white text-sm sm:text-base outline-none pr-1 pl-2 placeholder:text-slate-400"
              dir="rtl"
            />

            {searchQuery && (
              <button
                onClick={clearSearch}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                aria-label="مسح البحث"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={() => {
                if (activeTab === 'about') setActiveTab('tools');
              }}
              className="mr-2 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors shrink-0 shadow-md shadow-blue-900/40"
            >
              بحث فوري
            </button>
          </div>

          {searchQuery && (
            <p className="text-right text-xs text-blue-300 mt-2 pr-2">
              نتائج البحث الحالية عن: <span className="font-semibold text-white">"{searchQuery}"</span>
            </p>
          )}
        </div>

        {/* Unboxed Metadata Stats */}
        <div className="flex flex-wrap items-center justify-center gap-y-2 gap-x-4 sm:gap-x-6 text-xs sm:text-sm text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-blue-400 font-mono tabular-nums">{tools.length}</span>
            <span>أداة عالمية معتمدة</span>
          </div>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-purple-400 font-mono tabular-nums">{prompts.length}</span>
            <span>برومبت عربي احترافي</span>
          </div>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <div className="flex items-center gap-1.5 text-emerald-400">
            <ShieldCheck className="w-4 h-4" />
            <span>روابط أصلية بدون اشتراكات وهمية</span>
          </div>
          <span aria-hidden="true" className="text-slate-600 hidden sm:inline">·</span>
          <div className="flex items-center gap-1.5 text-slate-300 hidden sm:flex">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>نصائح للاستخدام في مصر</span>
          </div>
        </div>

      </div>
    </section>
  );
};
