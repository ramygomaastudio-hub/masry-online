import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { AITool, AICategoryId, PricingModel } from '../types';
import { AI_CATEGORIES } from '../data/initialData';
import { X, Plus, Check, AlertCircle } from 'lucide-react';

interface AddEditToolModalProps {
  isOpen: boolean;
  onClose: () => void;
  toolToEdit?: AITool | null;
}

export const AddEditToolModal: React.FC<AddEditToolModalProps> = ({
  isOpen,
  onClose,
  toolToEdit,
}) => {
  const { addCustomTool, updateTool } = useApp();

  const [name, setName] = useState('');
  const [arabicName, setArabicName] = useState('');
  const [category, setCategory] = useState<AICategoryId>('image');
  const [description, setDescription] = useState('');
  const [url, setUrl] = useState('');
  const [pricing, setPricing] = useState<PricingModel>('freemium');
  const [pricingNote, setPricingNote] = useState('');
  const [tipsForArabs, setTipsForArabs] = useState('');
  const [company, setCompany] = useState('');
  const [tagsStr, setTagsStr] = useState('');
  const [arabicSupport, setArabicSupport] = useState<'كامل' | 'جيد جداً' | 'متوسط' | 'إنجليزية ومترجم'>('جيد جداً');
  const [error, setError] = useState('');

  useEffect(() => {
    if (toolToEdit) {
      setName(toolToEdit.name);
      setArabicName(toolToEdit.arabicName);
      setCategory(toolToEdit.category);
      setDescription(toolToEdit.description);
      setUrl(toolToEdit.url);
      setPricing(toolToEdit.pricing);
      setPricingNote(toolToEdit.pricingNote || '');
      setTipsForArabs(toolToEdit.tipsForArabs || '');
      setCompany(toolToEdit.company);
      setTagsStr(toolToEdit.tags.join('، '));
      setArabicSupport(toolToEdit.arabicSupport);
    } else {
      setName('');
      setArabicName('');
      setCategory('image');
      setDescription('');
      setUrl('');
      setPricing('freemium');
      setPricingNote('');
      setTipsForArabs('');
      setCompany('');
      setTagsStr('');
      setArabicSupport('جيد جداً');
    }
    setError('');
  }, [toolToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !arabicName.trim() || !url.trim() || !description.trim()) {
      setError('يرجى ملء جميع الحقول الأساسية (الاسم العربي، الإنجليزي، الرابط، والوصف)');
      return;
    }

    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      setError('يجب أن يبدأ الرابط بـ https:// أو http://');
      return;
    }

    const tags = tagsStr
      .split(/[,،]/)
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    if (toolToEdit) {
      updateTool(toolToEdit.id, {
        name: name.trim(),
        arabicName: arabicName.trim(),
        category,
        description: description.trim(),
        url: url.trim(),
        pricing,
        pricingNote: pricingNote.trim(),
        tipsForArabs: tipsForArabs.trim() || 'أداة مضافة يدوياً إلى دليلك الشخصي.',
        company: company.trim() || name.trim(),
        tags: tags.length ? tags : ['أداة مخصصة'],
        arabicSupport,
      });
    } else {
      addCustomTool({
        name: name.trim(),
        arabicName: arabicName.trim(),
        category,
        description: description.trim(),
        url: url.trim(),
        pricing,
        pricingNote: pricingNote.trim() || 'حسب اشتراك المنصة',
        tipsForArabs: tipsForArabs.trim() || 'أداة مضافة يدوياً إلى دليلك الشخصي.',
        company: company.trim() || name.trim(),
        tags: tags.length ? tags : ['أداة مخصصة'],
        arabicSupport,
        rating: 4.8,
        reviewCount: 1,
        isVerified: true,
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl bg-[#0b1122] border border-blue-500/30 p-6 sm:p-7 shadow-2xl text-right"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-bold text-white mb-1">
          {toolToEdit ? 'تعديل بيانات الأداة' : 'إضافة أداة ذكاء اصطناعي جديدة'}
        </h2>
        <p className="text-xs text-slate-400 mb-5">
          احفظ أدواتك ومواقع الذكاء الاصطناعي المفضلة مباشرة في متصفحك
        </p>

        {error && (
          <div className="flex items-center gap-2 p-3 mb-4 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                الاسم باللغة العربية *
              </label>
              <input
                type="text"
                value={arabicName}
                onChange={(e) => setArabicName(e.target.value)}
                placeholder="مثال: لاما 3 أو إيليفن لابس"
                className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-blue-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                الاسم الأصلي (English) *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: Llama 3 أو ElevenLabs"
                className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-blue-500 outline-none font-mono"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              الرابط الرسمي للأداة (URL) *
            </label>
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com"
              className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-blue-500 outline-none font-mono text-left"
              dir="ltr"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                القسم الرئيسي *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as AICategoryId)}
                className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-blue-500 outline-none cursor-pointer"
              >
                {AI_CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                نوع التسعير *
              </label>
              <select
                value={pricing}
                onChange={(e) => setPricing(e.target.value as PricingModel)}
                className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-blue-500 outline-none cursor-pointer"
              >
                <option value="freemium">مجاني جزئياً (Freemium)</option>
                <option value="free">مجاني بالكامل (100% Free)</option>
                <option value="trial">تجربة مجانية مؤقتة</option>
                <option value="paid">اشتراك مدفوع فقط</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              الوصف والشرح بالعربية *
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="شرح موجز لما تقوم به الأداة وأهم ميزاتها..."
              className="w-full bg-[#070b16] border border-slate-800 rounded-xl p-3 text-white focus:border-blue-500 outline-none resize-none leading-relaxed"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              نصيحة الاستخدام للمستخدم المصري والعربي (اختياري)
            </label>
            <input
              type="text"
              value={tipsForArabs}
              onChange={(e) => setTipsForArabs(e.target.value)}
              placeholder="مثال: يدعم كروت الخصم المباشر، لا يحتاج VPN، خطة مجانية ممتازة..."
              className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-blue-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                الشركة المطورة
              </label>
              <input
                type="text"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                placeholder="مثال: Meta أو Google أو ناشئ"
                className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                الوسوم (مفصولة بفواصل)
              </label>
              <input
                type="text"
                value={tagsStr}
                onChange={(e) => setTagsStr(e.target.value)}
                placeholder="صور، مجاني، مصري، سريع"
                className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-blue-500 outline-none"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs sm:text-sm font-medium text-slate-300 hover:text-white bg-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-6 py-2 text-xs sm:text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-lg shadow-blue-900/40 transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>{toolToEdit ? 'حفظ التعديلات' : 'إضافة الأداة'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
