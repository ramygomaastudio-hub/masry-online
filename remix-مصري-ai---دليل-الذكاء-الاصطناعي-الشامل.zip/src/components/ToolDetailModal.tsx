import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  ExternalLink, 
  Heart, 
  Share2, 
  Star, 
  CheckCircle2, 
  Sparkles, 
  Globe2, 
  CreditCard, 
  ShieldCheck,
  Zap,
  Info
} from 'lucide-react';

export const ToolDetailModal: React.FC = () => {
  const { 
    selectedToolDetail, 
    setSelectedToolDetail, 
    isToolFavorite, 
    toggleFavoriteTool,
    showToast 
  } = useApp();

  if (!selectedToolDetail) return null;

  const tool = selectedToolDetail;
  const isFav = isToolFavorite(tool.id);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(tool.url);
    showToast(`تم نسخ الرابط الرسمي لـ ${tool.arabicName || tool.name}!`, 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-[#0b1122] border border-blue-500/30 p-6 sm:p-8 shadow-2xl shadow-black text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={() => setSelectedToolDetail(null)}
          className="absolute top-5 left-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-start gap-4 mb-6 pr-1">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-violet-600 p-0.5 shadow-lg shadow-blue-900/40 shrink-0">
            <div className="w-full h-full bg-[#080d1a] rounded-[14px] flex items-center justify-center text-xl font-bold text-blue-300">
              {tool.arabicName ? tool.arabicName.slice(0, 2) : 'AI'}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                {tool.arabicName}
              </h2>
              {tool.isVerified && (
                <span title="أداة معتمدة">
                  <CheckCircle2 className="w-5 h-5 text-blue-400 shrink-0" />
                </span>
              )}
            </div>

            <p className="text-sm font-mono text-slate-400 mt-0.5">
              {tool.name} · <span className="text-slate-500">{tool.company}</span>
            </p>

            <div className="flex flex-wrap items-center gap-2 mt-2">
              <span className="text-xs px-2.5 py-0.5 rounded-md bg-blue-500/15 text-blue-300 border border-blue-500/25 font-medium">
                {tool.category}
              </span>
              <div className="flex items-center gap-1 text-xs text-amber-400 font-mono">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                <span>{tool.rating.toFixed(1)}</span>
                <span className="text-slate-500">({tool.reviewCount.toLocaleString('ar-EG')} تقييم)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Description Section */}
        <div className="mb-6">
          <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            نبذة عن الأداة والقدرات
          </h4>
          <p className="text-sm sm:text-base text-slate-200 leading-relaxed bg-[#070b16] p-4 rounded-2xl border border-slate-800">
            {tool.description}
          </p>
        </div>

        {/* Key Features & Egyptian/Arab Insights Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
          
          {/* Card: Support for Arabic */}
          <div className="p-4 rounded-2xl bg-[#080f20] border border-slate-800 flex items-start gap-3">
            <Globe2 className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
            <div>
              <h5 className="text-xs font-bold text-white mb-1">دعم اللغة العربية</h5>
              <p className="text-xs text-slate-300">
                مستوى الدعم: <span className="text-sky-300 font-semibold">{tool.arabicSupport || 'جيد جداً'}</span>
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                تتعامل مع المدخلات العربية والنصوص بسلاسة.
              </p>
            </div>
          </div>

          {/* Card: Pricing & Payment */}
          <div className="p-4 rounded-2xl bg-[#080f20] border border-slate-800 flex items-start gap-3">
            <CreditCard className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h5 className="text-xs font-bold text-white mb-1">خطة الأسعار والدفع</h5>
              <p className="text-xs text-slate-300">
                {tool.pricingNote || (tool.pricing === 'free' ? 'مجاني تماماً' : 'يتوفر رصيد مجاني')}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                تقبل بطاقات الائتمان الدولية؛ ويتوفر بدائل مجانية يومية.
              </p>
            </div>
          </div>

        </div>

        {/* Dedicated Egyptian & Arab Pro Tips Callout */}
        <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-blue-950/40 to-indigo-950/30 border border-blue-500/30">
          <div className="flex items-center gap-2 text-blue-400 font-bold text-sm mb-2">
            <Sparkles className="w-4 h-4" />
            <span>دليل الاستخدام للمستخدم المصري والعربي:</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
            {tool.tipsForArabs}
          </p>
        </div>

        {/* Tags */}
        <div className="mb-6">
          <h4 className="text-xs font-semibold text-slate-400 mb-2">الكلمات المفتاحية والتصنيفات:</h4>
          <div className="flex flex-wrap gap-1.5">
            {tool.tags.map((tag, idx) => (
              <span key={idx} className="text-xs bg-slate-800/80 px-2.5 py-1 rounded-lg text-slate-300 border border-slate-700">
                #{tag}
              </span>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleFavoriteTool(tool.id)}
              className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
                isFav
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              <Heart className={`w-4 h-4 ${isFav ? 'text-rose-500 fill-rose-500' : ''}`} />
              <span>{isFav ? 'في المفضلة' : 'أضف للمفضلة'}</span>
            </button>

            <button
              onClick={handleCopyLink}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              <span>نسخ الرابط</span>
            </button>
          </div>

          <a
            href={tool.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-lg shadow-blue-900/40 transition-all cursor-pointer"
          >
            <span>زيارة الموقع الرسمي للأداة</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>

      </div>
    </div>
  );
};
