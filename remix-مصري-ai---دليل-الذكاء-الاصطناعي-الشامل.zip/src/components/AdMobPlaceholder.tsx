import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ExternalLink, Info, Eye, EyeOff, ShieldCheck } from 'lucide-react';

interface AdMobPlaceholderProps {
  type?: 'banner' | 'native' | 'interstitial_slot';
  className?: string;
}

export const AdMobPlaceholder: React.FC<AdMobPlaceholderProps> = ({ 
  type = 'banner',
  className = '' 
}) => {
  const { admobVisible, setAdmobVisible } = useApp();
  const [showConfigInfo, setShowConfigInfo] = useState(false);

  if (!admobVisible) {
    return null;
  }

  if (type === 'banner') {
    return (
      <div className={`w-full my-6 flex flex-col items-center justify-center ${className}`}>
        {/* Banner container */}
        <div className="relative w-full max-w-4xl rounded-xl border border-dashed border-blue-500/30 bg-[#0a1020]/90 p-3 sm:p-4 text-center overflow-hidden">
          
          {/* Top Label */}
          <div className="flex items-center justify-between gap-2 mb-2 px-1 text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5 text-blue-400 font-mono">
              <span className="w-2 h-2 rounded-full bg-blue-500"></span>
              <span>Google AdMob Banner Placeholder</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-300 font-sans">مساحة إعلانية مخصصة للموبايل والويب</span>
            </div>

            <div className="flex items-center gap-2">
              <button 
                onClick={() => setShowConfigInfo(!showConfigInfo)}
                className="text-slate-400 hover:text-blue-300 transition-colors flex items-center gap-1 text-[11px] cursor-pointer"
              >
                <Info className="w-3.5 h-3.5" />
                <span>{showConfigInfo ? 'إخفاء المعرفات' : 'إعدادات المعرفات'}</span>
              </button>

              <button 
                onClick={() => setAdmobVisible(false)}
                className="text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                title="إخفاء المعاينة مؤقتاً"
              >
                <EyeOff className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Ad Mock Graphics (Responsive: 728x90 desktop / 320x50 mobile) */}
          <div className="mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 bg-gradient-to-r from-slate-900/90 via-[#0d162d] to-slate-900/90 rounded-lg p-3 sm:px-6 border border-slate-800">
            <div className="flex items-center gap-3 text-right">
              <div className="w-10 h-10 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 shrink-0 font-bold text-sm">
                Ad
              </div>
              <div>
                <p className="text-xs sm:text-sm font-semibold text-white">
                  مساحة إعلانات Google AdMob المتجاوبة
                </p>
                <p className="text-[11px] text-slate-400">
                  جاهزة للربط مع كود الإعلانات أو Google AdSense / AdMob SDK للتطبيقات
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                Format: Adaptive Banner (320x50 / 728x90)
              </span>
            </div>
          </div>

          {/* Config Info Dropdown */}
          {showConfigInfo && (
            <div className="mt-3 p-3 bg-black/40 rounded-lg border border-slate-800 text-right text-xs text-slate-300 space-y-1">
              <div className="font-semibold text-blue-300">ملاحظة تقنية للمطور / المالك:</div>
              <p className="text-slate-400">
                تم تخصيص هذا الموضع لتشغيل إعلانات AdMob الفعلية لاحقاً عند نشر التطبيق على متجر Google Play أو Apple App Store باستخدام AdMob Application ID ووحدة الإعلانات (Ad Unit ID).
              </p>
              <div className="font-mono text-[11px] text-slate-400 mt-1">
                Sample Test Unit ID: <span className="text-amber-400">ca-app-pub-3940256099942544/6300978111</span>
              </div>
            </div>
          )}

        </div>
      </div>
    );
  }

  // Native In-Feed Ad slot (looks like a tool card in grid)
  return (
    <div className={`flex flex-col justify-between rounded-2xl bg-[#090e1c] border border-dashed border-blue-500/30 p-5 ${className}`}>
      <div>
        <div className="flex items-center justify-between mb-3 text-[11px] text-slate-400">
          <span className="px-2 py-0.5 rounded bg-blue-500/15 text-blue-300 border border-blue-500/25 font-mono text-[10px]">
            Google AdMob Native Ad
          </span>
          <span className="text-slate-500">إعلان تجريبي مخصص</span>
        </div>

        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 rounded-xl bg-blue-950/40 border border-blue-500/20 flex items-center justify-center text-blue-400 font-bold">
            Ad
          </div>
          <div>
            <h4 className="font-bold text-white text-sm sm:text-base">
              مساحة إعلان أصلي مدمج (Native Card)
            </h4>
            <p className="text-xs text-slate-400">
              تصميم منسجم تماماً مع بطاقات الأدوات والبرومبتات
            </p>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed mb-4">
          يضمن هذا الموضع تحقيق دخل مستمر عبر AdMob Native Ads دون التأثير سلباً على تجربة المستخدم وسلاسة التصفح في الهواتف وأجهزة الكمبيوتر.
        </p>
      </div>

      <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
        <span className="text-slate-500 font-mono text-[11px]">ca-app-pub-xxxxxxx/native</span>
        <span className="px-3 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs">
          مساحة جاهزة للربط
        </span>
      </div>
    </div>
  );
};
