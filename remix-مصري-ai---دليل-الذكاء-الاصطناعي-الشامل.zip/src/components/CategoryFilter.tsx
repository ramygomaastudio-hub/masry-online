import React from 'react';
import { useApp } from '../context/AppContext';
import { AI_CATEGORIES } from '../data/initialData';
import { AICategoryId, PricingModel } from '../types';
import { 
  Sparkles, 
  Image as ImageIcon, 
  Video, 
  Music, 
  Mic, 
  PenTool, 
  Languages, 
  Code2, 
  MessageSquareText, 
  Filter
} from 'lucide-react';

export const CategoryFilter: React.FC = () => {
  const { 
    selectedCategory, 
    setSelectedCategory, 
    pricingFilter, 
    setPricingFilter,
    tools 
  } = useApp();

  const getCategoryIcon = (id: AICategoryId) => {
    switch (id) {
      case 'image': return <ImageIcon className="w-4 h-4" />;
      case 'video': return <Video className="w-4 h-4" />;
      case 'music': return <Music className="w-4 h-4" />;
      case 'audio': return <Mic className="w-4 h-4" />;
      case 'writing': return <PenTool className="w-4 h-4" />;
      case 'translation': return <Languages className="w-4 h-4" />;
      case 'code': return <Code2 className="w-4 h-4" />;
      case 'chat': return <MessageSquareText className="w-4 h-4" />;
      default: return <Sparkles className="w-4 h-4" />;
    }
  };

  const getCategoryCount = (id: AICategoryId | 'all') => {
    if (id === 'all') return tools.length;
    return tools.filter((t) => t.category === id).length;
  };

  return (
    <div className="w-full space-y-4">
      {/* Category Segmented Scrollable Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none pt-1">
        {/* All Categories Button */}
        <button
          onClick={() => setSelectedCategory('all')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            selectedCategory === 'all'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 ring-1 ring-blue-400/50'
              : 'bg-[#0f172a] text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-blue-300" />
          <span>كل الأقسام</span>
          <span className="font-mono text-xs opacity-75 bg-black/20 px-1.5 py-0.5 rounded">
            {getCategoryCount('all')}
          </span>
        </button>

        {/* Dynamic Category Buttons */}
        {AI_CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          const count = getCategoryCount(cat.id);
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
                isSelected
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-600/30 ring-1 ring-blue-400/50'
                  : 'bg-[#0f172a] text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800/80'
              }`}
            >
              {getCategoryIcon(cat.id)}
              <span>{cat.name}</span>
              <span className="font-mono text-xs opacity-75 bg-black/20 px-1.5 py-0.5 rounded">
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Sub-bar: Pricing Filter & Quick Info */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-800/60 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-slate-300 font-medium">نوع التسعير:</span>
          
          <div className="inline-flex rounded-lg bg-slate-900/90 p-0.5 border border-slate-800">
            <button
              onClick={() => setPricingFilter('all')}
              className={`px-2.5 py-1 rounded-md text-xs transition-colors cursor-pointer ${
                pricingFilter === 'all'
                  ? 'bg-blue-600 text-white font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              الكل
            </button>
            <button
              onClick={() => setPricingFilter('free')}
              className={`px-2.5 py-1 rounded-md text-xs transition-colors cursor-pointer ${
                pricingFilter === 'free'
                  ? 'bg-emerald-600 text-white font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              مجاني بالكامل
            </button>
            <button
              onClick={() => setPricingFilter('freemium')}
              className={`px-2.5 py-1 rounded-md text-xs transition-colors cursor-pointer ${
                pricingFilter === 'freemium'
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              مجاني جزئياً (Freemium)
            </button>
            <button
              onClick={() => setPricingFilter('paid')}
              className={`px-2.5 py-1 rounded-md text-xs transition-colors cursor-pointer ${
                pricingFilter === 'paid'
                  ? 'bg-purple-600 text-white font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              مدفوع
            </button>
          </div>
        </div>

        <div className="text-slate-400 text-xs">
          <span>تلميح: جميع الروابط تنقلك للمواقع الرسمية المباشرة للأدوات دون اشتراكات وسيطة</span>
        </div>
      </div>
    </div>
  );
};
