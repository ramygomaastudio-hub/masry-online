import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, 
  Wrench, 
  BookOpen, 
  Heart, 
  Info, 
  Plus, 
  Settings2, 
  Menu, 
  X,
  ExternalLink
} from 'lucide-react';

interface HeaderProps {
  onOpenAddTool: () => void;
  onOpenBackup: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenAddTool, onOpenBackup }) => {
  const { activeTab, setActiveTab, favoriteToolIds, favoritePromptIds } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const totalFavorites = favoriteToolIds.length + favoritePromptIds.length;

  const handleNavClick = (tab: 'tools' | 'prompts' | 'favorites' | 'about') => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#070b16]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 gap-4 sm:gap-8">
          
          {/* Zone 1: Brand Wordmark (Single element) */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => handleNavClick('tools')}
              className="flex items-center gap-2.5 text-right group cursor-pointer focus:outline-none"
              aria-label="الرئيسية - مصري AI"
            >
              {/* Modern Egyptian AI Icon */}
              <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-violet-500 p-0.5 shadow-lg shadow-blue-500/20 group-hover:shadow-blue-500/40 transition-shadow">
                <div className="w-full h-full bg-[#090e1f] rounded-[10px] flex items-center justify-center">
                  <span className="text-transparent bg-clip-text bg-gradient-to-tr from-blue-400 to-violet-300 font-extrabold text-lg">
                    مـAI
                  </span>
                </div>
              </div>

              <div className="flex flex-col text-right">
                <span className="text-xl font-bold tracking-tight text-white group-hover:text-blue-300 transition-colors whitespace-nowrap">
                  مصري <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400">AI</span>
                </span>
                <span className="text-[11px] text-slate-400 font-normal leading-tight hidden xs:inline-block">
                  دليل الذكاء الاصطناعي العربي
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links (Single line, desktop) */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            <button
              onClick={() => handleNavClick('tools')}
              className={`flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-all whitespace-nowrap ${
                activeTab === 'tools'
                  ? 'bg-blue-600/15 text-blue-300 border border-blue-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Wrench className="w-4 h-4 text-blue-400" />
              <span>الأدوات والمنصات</span>
            </button>

            <button
              onClick={() => handleNavClick('prompts')}
              className={`flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-all whitespace-nowrap ${
                activeTab === 'prompts'
                  ? 'bg-blue-600/15 text-blue-300 border border-blue-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <BookOpen className="w-4 h-4 text-purple-400" />
              <span>مكتبة البرومبتات</span>
            </button>

            <button
              onClick={() => handleNavClick('favorites')}
              className={`flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-all whitespace-nowrap ${
                activeTab === 'favorites'
                  ? 'bg-blue-600/15 text-blue-300 border border-blue-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Heart className={`w-4 h-4 ${totalFavorites > 0 ? 'text-rose-400 fill-rose-400' : 'text-slate-400'}`} />
              <span>المفضلة</span>
              {totalFavorites > 0 && (
                <span className="mr-1 px-1.5 py-0.2 text-[11px] font-mono bg-rose-500/20 text-rose-300 rounded-full border border-rose-500/30">
                  {totalFavorites}
                </span>
              )}
            </button>

            <button
              onClick={() => handleNavClick('about')}
              className={`flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-all whitespace-nowrap ${
                activeTab === 'about'
                  ? 'bg-blue-600/15 text-blue-300 border border-blue-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Info className="w-4 h-4 text-emerald-400" />
              <span>عن التطبيق</span>
            </button>
          </nav>

          {/* Zone 3: Primary Action & Utilities */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              onClick={onOpenAddTool}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 rounded-lg shadow-md shadow-blue-900/30 transition-all whitespace-nowrap active:scale-95 cursor-pointer"
              title="أضف أداة جديدة إلى دليلك المحلي"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">أضف أداة</span>
              <span className="sm:hidden">إضافة</span>
            </button>

            <button
              onClick={onOpenBackup}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800/60 rounded-lg border border-slate-700/60 transition-colors"
              title="إدارة البيانات والنسخ الاحتياطي"
              aria-label="إدارة البيانات"
            >
              <Settings2 className="w-4 h-4" />
            </button>

            {/* Mobile Hamburger toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-300 hover:text-white hover:bg-slate-800/60 rounded-lg border border-slate-700/60"
              aria-label="القائمة"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden py-3 border-t border-slate-800 space-y-1">
            <button
              onClick={() => handleNavClick('tools')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm ${
                activeTab === 'tools' ? 'bg-blue-600/20 text-blue-300' : 'text-slate-300 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Wrench className="w-4 h-4 text-blue-400" />
                <span>دليل الأدوات والمنصات</span>
              </div>
            </button>

            <button
              onClick={() => handleNavClick('prompts')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm ${
                activeTab === 'prompts' ? 'bg-blue-600/20 text-blue-300' : 'text-slate-300 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <BookOpen className="w-4 h-4 text-purple-400" />
                <span>مكتبة البرومبتات العربية</span>
              </div>
            </button>

            <button
              onClick={() => handleNavClick('favorites')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm ${
                activeTab === 'favorites' ? 'bg-blue-600/20 text-blue-300' : 'text-slate-300 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Heart className={`w-4 h-4 ${totalFavorites > 0 ? 'text-rose-400 fill-rose-400' : 'text-slate-400'}`} />
                <span>المفضلة والمحفوظات</span>
              </div>
              {totalFavorites > 0 && (
                <span className="px-2 py-0.5 text-xs font-mono bg-rose-500/20 text-rose-300 rounded-full border border-rose-500/30">
                  {totalFavorites}
                </span>
              )}
            </button>

            <button
              onClick={() => handleNavClick('about')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm ${
                activeTab === 'about' ? 'bg-blue-600/20 text-blue-300' : 'text-slate-300 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Info className="w-4 h-4 text-emerald-400" />
                <span>عن مصري AI والدليل</span>
              </div>
            </button>
          </div>
        )}

      </div>
    </header>
  );
};
