import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PromptCategoryId } from '../types';
import { X, Check, AlertCircle } from 'lucide-react';

interface AddEditPromptModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AddEditPromptModal: React.FC<AddEditPromptModalProps> = ({ isOpen, onClose }) => {
  const { addCustomPrompt } = useApp();

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<PromptCategoryId>('writing');
  const [recommendedTool, setRecommendedTool] = useState('');
  const [promptText, setPromptText] = useState('');
  const [explanation, setExplanation] = useState('');
  const [tagsStr, setTagsStr] = useState('');
  const [difficulty, setDifficulty] = useState<'مبتدئ' | 'متوسط' | 'متقدم'>('مبتدئ');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !promptText.trim() || !recommendedTool.trim()) {
      setError('يرجى كتابة عنوان البرومبت، الأداة المقترحة، ونص البرومبت');
      return;
    }

    const tags = tagsStr
      .split(/[,،]/)
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    // Extract placeholders like [variable]
    const matches = promptText.match(/\[[^\]]+\]/g) || [];
    const variables = Array.from(new Set(matches));

    addCustomPrompt({
      title: title.trim(),
      category,
      recommendedTool: recommendedTool.trim(),
      promptText: promptText.trim(),
      explanation: explanation.trim() || 'برومبت مخصص محفوظ في مكتبتك.',
      tags: tags.length ? tags : ['برومبت مخصص'],
      variables,
      difficulty,
    });

    // Reset
    setTitle('');
    setPromptText('');
    setExplanation('');
    setTagsStr('');
    setRecommendedTool('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl bg-[#0b1122] border border-purple-500/30 p-6 sm:p-7 shadow-2xl text-right"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-bold text-white mb-1">
          إضافة برومبت عربي جديد للمكتبة
        </h2>
        <p className="text-xs text-slate-400 mb-5">
          احفظ أوامرك الاحترافية المجرّبة واستخدم الأقواس مثل <span className="text-amber-400 font-mono">[اسم المتغير]</span> لتحديد الحقول القابلة للتغيير
        </p>

        {error && (
          <div className="flex items-center gap-2 p-3 mb-4 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              عنوان البرومبت *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: كتابة بوست فيسبوك بالعامية المصرية"
              className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-purple-500 outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                القسم *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as PromptCategoryId)}
                className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-purple-500 outline-none cursor-pointer"
              >
                <option value="marketing">تسويق وإعلانات</option>
                <option value="images">توليد صور وفن</option>
                <option value="writing">مقالات ومحتوى</option>
                <option value="music">أغاني وتلحين</option>
                <option value="code">برمجة وأكواد</option>
                <option value="study">دراسة وأبحاث</option>
                <option value="business">أعمال وعروض</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                الأداة المقترحة *
              </label>
              <input
                type="text"
                value={recommendedTool}
                onChange={(e) => setRecommendedTool(e.target.value)}
                placeholder="مثال: ChatGPT-4o / Midjourney / Suno"
                className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-purple-500 outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              نص البرومبت بالكامل *
            </label>
            <textarea
              rows={5}
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              placeholder="اكتب البرومبت هنا... استخدم [اسم المنتج] أو [الموضوع] للمتغيرات"
              className="w-full bg-[#070b16] border border-slate-800 rounded-xl p-3 text-white focus:border-purple-500 outline-none resize-none leading-relaxed font-sans"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              إرشادات وكيفية استخدام البرومبت
            </label>
            <input
              type="text"
              value={explanation}
              onChange={(e) => setExplanation(e.target.value)}
              placeholder="شرح بسيط للنتيجة المتوقعة وطريقة تخصيصه..."
              className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-purple-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                مستوى الصعوبة
              </label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as any)}
                className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-purple-500 outline-none cursor-pointer"
              >
                <option value="مبتدئ">مبتدئ</option>
                <option value="متوسط">متوسط</option>
                <option value="متقدم">متقدم</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                الوسوم (مفصولة بفواصل)
              </label>
              <input
                type="text"
                value={tagsStr}
                onChange={(e) => setTagsStr(e.target.value)}
                placeholder="تسويق، مصر، إعلان، كتابة"
                className="w-full bg-[#070b16] border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:border-purple-500 outline-none"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs sm:text-sm font-medium text-slate-300 hover:text-white bg-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-6 py-2 text-xs sm:text-sm font-bold text-white bg-purple-600 hover:bg-purple-500 rounded-xl shadow-lg shadow-purple-900/40 transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>إضافة البرومبت</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
