import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PromptCard } from './PromptCard';
import { AdMobPlaceholder } from './AdMobPlaceholder';
import { PromptCategoryId } from '../types';
import { 
  Sparkles, 
  Plus, 
  BookOpen, 
  PenTool, 
  Image as ImageIcon, 
  Video, 
  Music, 
  Code2, 
  TrendingUp, 
  GraduationCap, 
  Briefcase 
} from 'lucide-react';
import { AddEditPromptModal } from './AddEditPromptModal';

export const PromptsView: React.FC = () => {
  const { 
    filteredPrompts, 
    selectedPromptCategory, 
    setSelectedPromptCategory,
    searchQuery,
    prompts 
  } = useApp();

  const [addModalOpen, setAddModalOpen] = useState(false);

  const categories: { id: PromptCategoryId | 'all'; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: 'كل البرومبتات', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'marketing', label: 'تسويق وإعلانات', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'images', label: 'صور وفنون', icon: <ImageIcon className="w-4 h-4" /> },
    { id: 'writing', label: 'مقالات وكتابة', icon: <PenTool className="w-4 h-4" /> },
    { id: 'music', label: 'أغاني وتلحين', icon: <Music className="w-4 h-4" /> },
    { id: 'video', label: 'سيناريو وفيديو', icon: <Video className="w-4 h-4" /> },
    { id: 'code', label: 'برمجة وتطوير', icon: <Code2 className="w-4 h-4" /> },
    { id: 'study', label: 'دراسة وأبحاث', icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'business', label: 'أعمال ومشاريع', icon: <Briefcase className="w-4 h-4" /> },
  ];

  return (
    <div className="space-y-8">
      {/* Top Header of Prompts View */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-5 h-5 text-purple-400" />
            <h2 className="text-xl sm:text-2xl font-bold text-white">
              مكتبة البرومبتات والأوامر العربية
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-400">
            أوامر جاهزة ومجرّبة مسبقاً لصناع المحتوى والمسوقين والمبرمجين مع خانات متغيرات <span className="text-amber-400 font-mono">[بين أقواس]</span>
          </p>
        </div>

        <button
          onClick={() => setAddModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-white bg-purple-600 hover:bg-purple-500 shadow-md shadow-purple-900/40 transition-all cursor-pointer whitespace-nowrap active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>أضف برومبت جديد</span>
        </button>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const isSelected = selectedPromptCategory === cat.id;
          const count = cat.id === 'all' 
            ? prompts.length 
            : prompts.filter((p) => p.category === cat.id).length;

          return (
            <button
              key={cat.id}
              onClick={() => setSelectedPromptCategory(cat.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all shrink-0 cursor-pointer ${
                isSelected
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'bg-[#0f172a] text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {cat.icon}
              <span>{cat.label}</span>
              <span className="font-mono text-xs opacity-75 bg-black/20 px-1.5 py-0.5 rounded">
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Prompts Grid */}
      {filteredPrompts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredPrompts.map((prompt, index) => (
            <React.Fragment key={prompt.id}>
              <PromptCard prompt={prompt} />
              {/* Insert native ad slot cleanly after index 2 for preview */}
              {index === 2 && (
                <div className="md:col-span-2">
                  <AdMobPlaceholder type="native" />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 px-4 rounded-3xl bg-[#0a1020] border border-slate-800">
          <BookOpen className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-1">
            لا توجد برومبتات مطابقة للبحث
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mb-4">
            {searchQuery
              ? `لم يتم العثور على أوامر تطابق "${searchQuery}"`
              : 'لم تتم إضافة أوامر في هذا القسم بعد'}
          </p>
          <button
            onClick={() => setAddModalOpen(true)}
            className="px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-purple-600 text-white hover:bg-purple-500 transition-colors"
          >
            أضف أول برومبت الآن
          </button>
        </div>
      )}

      {/* Modal to add custom prompt */}
      <AddEditPromptModal 
        isOpen={addModalOpen} 
        onClose={() => setAddModalOpen(false)} 
      />
    </div>
  );
};
