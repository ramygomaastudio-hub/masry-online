import React from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  CreditCard, 
  Globe2, 
  Smartphone, 
  Heart, 
  Layers, 
  Code2, 
  HelpCircle,
  Zap,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AboutView: React.FC = () => {
  const { setActiveTab } = useApp();

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-10 text-right">
      
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0c152d] via-[#090f20] to-[#070b16] border border-blue-500/30 p-6 sm:p-10 shadow-2xl">
        <div 
          aria-hidden="true" 
          className="pointer-events-none absolute -top-16 -left-16 w-64 h-64 bg-blue-600/20 rounded-full blur-3xl" 
        />
        
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/15 border border-blue-500/30 text-blue-300 text-xs font-medium mb-4">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>رسالتنا: تمكين المبدع العربي في عصر الذكاء الاصطناعي</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white leading-tight mb-4">
            عن منصة <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-violet-400">«مصري AI»</span>
          </h2>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            «مصري AI» هو دليل تقني عربي شامل ومجاني، صُمم خصيصاً للمستخدم والمبدع والمهندس والطالب في مصر والوطن العربي لمساعدتهم في استكشاف وتوظيف أقوى أدوات الذكاء الاصطناعي الحقيقية دون الوقوع في فخ المنصات الوهمية أو الاشتراكات الوسيطة المضللة.
          </p>

          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => setActiveTab('tools')}
              className="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-900/40 transition-colors cursor-pointer"
            >
              استكشف الأدوات الآن
            </button>
            <button
              onClick={() => setActiveTab('prompts')}
              className="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
            >
              تصفح مكتبة البرومبتات
            </button>
          </div>
        </div>
      </div>

      {/* Core Principles */}
      <div>
        <h3 className="text-xl font-bold text-white mb-5 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-blue-400" />
          <span>المبادئ الخمسة لمنصة «مصري AI»</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          <div className="p-5 rounded-2xl bg-[#0c1324] border border-slate-800 hover:border-blue-500/30 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/25 flex items-center justify-center text-blue-400 mb-3 font-bold">
              1
            </div>
            <h4 className="text-base font-bold text-white mb-1.5">روابط أصلية ومباشرة 100%</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              جميع الروابط في التطبيق توجهك مباشرة إلى المنصات الرسمية العالمية لأصحاب الأدوات (OpenAI، Midjourney، Anthropic، Google...) ولا نستخدم أي واجهات وهمية.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#0c1324] border border-slate-800 hover:border-purple-500/30 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-purple-600/15 border border-purple-500/25 flex items-center justify-center text-purple-400 mb-3 font-bold">
              2
            </div>
            <h4 className="text-base font-bold text-white mb-1.5">مجاني بالكامل وبدون اشتراكات في النسخة الأولى</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              الدليل مجاني لكافة الطلاب وصناع المحتوى والباحثين، ولا يتطلب أي اشتراك شهري أو تسجيل دخول معقد لتصفح الأدوات ونسخ الأوامر.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#0c1324] border border-slate-800 hover:border-amber-500/30 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-amber-600/15 border border-amber-500/25 flex items-center justify-center text-amber-400 mb-3 font-bold">
              3
            </div>
            <h4 className="text-base font-bold text-white mb-1.5">نصائح مخصصة للبيئة المصرية والعربية</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              نوفر مع كل أداة معلومات عملية حول مدى دعم اللهجة المصرية، وتوافر الخطط المجانية اليومية، وكيفية التعامل مع متطلبات الدفع من داخل مصر.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#0c1324] border border-slate-800 hover:border-emerald-500/30 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/15 border border-emerald-500/25 flex items-center justify-center text-emerald-400 mb-3 font-bold">
              4
            </div>
            <h4 className="text-base font-bold text-white mb-1.5">حفظ محلي وحرية التعديل والتصدير</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              مفضلاتك وأدواتك المخصصة تُحفظ محلياً على جهازك بواسطة LocalStorage مع إمكانية التصدير والاستيراد بصيغة JSON في أي وقت.
            </p>
          </div>

        </div>
      </div>

      {/* Guide for Egyptian Users: Payment & Access */}
      <div className="p-6 rounded-3xl bg-[#0a1122] border border-blue-900/40 space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-emerald-400" />
          <span>دليل التعامل مع مدفوعات الذكاء الاصطناعي في مصر</span>
        </h3>

        <div className="space-y-3 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <p>
            تواجه بعض بطاقات الخصم المباشر (Debit) والمدفوعات الدولية قيوداً دورية في مصر. إليك أهم الحلول البديلة المجرّبة:
          </p>
          
          <ul className="list-disc list-inside space-y-2 pr-2 text-slate-400">
            <li>
              <span className="text-white font-semibold">البدائل المجانية الجبارة:</span> يمكنك استخدام نموذج <strong className="text-blue-300">FLUX.1</strong> مجاناً عبر منصات Replicate وFal وPoe كبديل كامل لميدجورني، ونموذج <strong className="text-blue-300">Google Gemini 2.0</strong> و<strong className="text-blue-300">Claude 3.7 Sonnet</strong> بحصصهما اليومية المجانية.
            </li>
            <li>
              <span className="text-white font-semibold">كروت الائتمان (Credit Cards):</span> تعمل معظم بطاقات الائتمان الصادرة من البنوك المصرية (CIB, QNB, NBE, Banque Misr) بشكل طبيعي مع الاشتراكات الدولية بعد تفعيل المعاملات الدولية وفق الحد المتاح لبطاقتك.
            </li>
            <li>
              <span className="text-white font-semibold">بطاقات الدفع الافتراضية الموثوقة:</span> مثل RedotPay أو بطاقات الدفع بالعملات الرقمية المقبولة في منصات الذكاء الاصطناعي.
            </li>
            <li>
              <span className="text-white font-semibold">البريد الإلكتروني الجامعي:</span> يمنحك اشتراك GitHub Copilot مجاناً 100% ويمنحك خصومات هائلة عبر حزم الطلاب الرسمية.
            </li>
          </ul>
        </div>
      </div>

      {/* Technical Readiness / AdMob Disclosure */}
      <div className="p-6 rounded-3xl bg-[#090e1c] border border-slate-800 text-xs text-slate-400 leading-relaxed space-y-2">
        <div className="flex items-center gap-2 font-bold text-white text-sm">
          <Smartphone className="w-4 h-4 text-purple-400" />
          <span>التوافق مع الهواتف الذكية وتصدير Google AdMob</span>
        </div>
        <p>
          تم بناء هذا التطبيق بتصميم عصري فائق السرعة متجاوب بنسبة 100% مع هواتف الأندرويد والآيفون وشاشات الكمبيوتر والتابلت. تم تجهيز مساحات إعلانية قياسية مخصصة لـ Google AdMob (Adaptive Banners & Native Cards) في الكود، وهي مهيأة للربط الفعلي عند تحويل المشروع إلى تطبيق أندرويد عبر Capacitor أو React Native أو عند إطلاق إعلانات الويب.
        </p>
      </div>

      {/* Footer Info */}
      <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <div>
          تطبيق «مصري AI» - إصدار 1.0.0 (نسخة 2026) · صُمم بحب لأجل مجتمع المبدعين والمبرمجين العرب
        </div>
        <div className="flex items-center gap-1 text-slate-400">
          <span>دعم واستفسارات:</span>
          <span className="font-mono text-blue-400">support@masry-ai.com</span>
        </div>
      </div>

    </div>
  );
};
