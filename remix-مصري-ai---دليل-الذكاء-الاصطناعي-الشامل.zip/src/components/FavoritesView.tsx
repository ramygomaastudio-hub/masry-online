import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ToolCard } from './ToolCard';
import { PromptCard } from './PromptCard';
import { Heart, Wrench, BookOpen, Sparkles } from 'lucide-react';

export const FavoritesView: React.FC = () => {
  const { 
    tools, 
    prompts, 
    favoriteToolIds, 
    favoritePromptIds, 
    setActiveTab 
  } = useApp();

  const [favSubTab, setFavSubTab] = useState<'all' | 'tools' | 'prompts'>('all');

  const favoritedTools = tools.filter((t) => favoriteToolIds.includes(t.id));
  const favoritedPrompts = prompts.filter((p) => favoritePromptIds.includes(p.id));

  const totalFavs = favoritedTools.length + favoritedPrompts.length;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
            <h2 className="text-xl sm:text-2xl font-bold text-white">
              قائمة المفضلة والمحفوظات
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-400">
            أدواتك المفضلة وأوامرك المحفوظة محلياً على جهازك لسهولة الوصول السريع
          </p>
        </div>

        {/* Sub-tabs */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs">
          <button
            onClick={() => setFavSubTab('all')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
              favSubTab === 'all'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            الكل ({totalFavs})
          </button>
          <button
            onClick={() => setFavSubTab('tools')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
              favSubTab === 'tools'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            الأدوات ({favoritedTools.length})
          </button>
          <button
            onClick={() => setFavSubTab('prompts')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
              favSubTab === 'prompts'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            البرومبتات ({favoritedPrompts.length})
          </button>
        </div>
      </div>

      {/* Content based on sub-tab */}
      {totalFavs === 0 ? (
        <div className="text-center py-20 px-4 rounded-3xl bg-[#0a1020] border border-slate-800">
          <Heart className="w-16 h-16 text-slate-700 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-white mb-2">
            لم تقم بإضافة عناصر للمفضلة بعد
          </h3>
          <p className="text-sm text-slate-400 max-w-md mx-auto mb-6">
            انقر على أيقونة القلب <span className="text-rose-400">❤️</span> بجانب أي أداة أو برومبت لحفظها هنا والوصول إليها بسرعة من أي جهاز.
          </p>
          <div className="flex justify-center gap-3">
            <button
              onClick={() => setActiveTab('tools')}
              className="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-900/40 transition-colors"
            >
              استعراض الأدوات
            </button>
            <button
              onClick={() => setActiveTab('prompts')}
              className="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
            >
              استعراض البرومبتات
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-10">
          
          {/* Favorited Tools Section */}
          {(favSubTab === 'all' || favSubTab === 'tools') && favoritedTools.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Wrench className="w-4 h-4 text-blue-400" />
                <h3 className="font-bold text-lg text-white">
                  الأدوات المحفوظة ({favoritedTools.length})
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {favoritedTools.map((tool) => (
                  <ToolCard key={tool.id} tool={tool} />
                ))}
              </div>
            </div>
          )}

          {/* Favorited Prompts Section */}
          {(favSubTab === 'all' || favSubTab === 'prompts') && favoritedPrompts.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <BookOpen className="w-4 h-4 text-purple-400" />
                <h3 className="font-bold text-lg text-white">
                  البرومبتات المحفوظة ({favoritedPrompts.length})
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {favoritedPrompts.map((prompt) => (
                  <PromptCard key={prompt.id} prompt={prompt} />
                ))}
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
};
