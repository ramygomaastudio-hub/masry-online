import React from 'react';
import { useApp } from '../context/AppContext';
import { Heart, Sparkles, ExternalLink, Shield } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setActiveTab } = useApp();

  return (
    <footer className="w-full mt-20 border-t border-slate-800/80 bg-[#060a14] py-12 text-slate-400 text-xs text-right">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          
          {/* Col 1: Brand & Bio */}
          <div className="space-y-3 md:col-span-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 to-violet-500 flex items-center justify-center text-white font-bold text-sm">
                مـAI
              </div>
              <span className="text-lg font-bold text-white">
                مصري <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">AI</span>
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed max-w-md">
              دليلك العربي الموثوق لأقوى أدوات الذكاء الاصطناعي العالمية ومكتبة الأوامر الاحترافية. تم تجميع الروابط والنصائح خصيصاً لدعم المبدعين والمهندسين والطلبة في مصر والوطن العربي.
            </p>
            <div className="flex items-center gap-2 text-slate-500 pt-1">
              <Shield className="w-3.5 h-3.5 text-blue-400" />
              <span>روابط حقيقية 100% · لا توجد روبوتات أو اشتراكات وهمية</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-white mb-2">أقسام المنصة</h4>
            <ul className="space-y-1.5">
              <li>
                <button 
                  onClick={() => setActiveTab('tools')} 
                  className="hover:text-blue-300 transition-colors cursor-pointer"
                >
                  دليل الأدوات والمنصات
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('prompts')} 
                  className="hover:text-blue-300 transition-colors cursor-pointer"
                >
                  مكتبة البرومبتات العربية
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('favorites')} 
                  className="hover:text-blue-300 transition-colors cursor-pointer"
                >
                  قائمة المفضلة والمحفوظات
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('about')} 
                  className="hover:text-blue-300 transition-colors cursor-pointer"
                >
                  عن التطبيق ودليل الدفع
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Categories & Advice */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-white mb-2">أشهر الأقسام</h4>
            <div className="flex flex-wrap gap-1.5 text-[11px]">
              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">توليد الصور والفن</span>
              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">توليد الفيديو 4K</span>
              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">الأغاني والموسيقى</span>
              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">البرمجة ومحررات الكود</span>
              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">دبلجة واستنساخ الصوت</span>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500">
          <p>© {new Date().getFullYear()} مصري AI (Masry AI). جميع الحقوق محفوظة لأسماء الأدوات وعلاماتها التجارية لأصحابها الرسميين.</p>
          <div className="flex items-center gap-1">
            <span>صُنع بشغف للمجتمع العربي</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 inline" />
          </div>
        </div>
      </div>
    </footer>
  );
};
