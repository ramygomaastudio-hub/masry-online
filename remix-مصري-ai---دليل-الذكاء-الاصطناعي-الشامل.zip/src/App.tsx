import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { CategoryFilter } from './components/CategoryFilter';
import { ToolCard } from './components/ToolCard';
import { PromptsView } from './components/PromptsView';
import { FavoritesView } from './components/FavoritesView';
import { AboutView } from './components/AboutView';
import { AdMobPlaceholder } from './components/AdMobPlaceholder';
import { ToolDetailModal } from './components/ToolDetailModal';
import { AddEditToolModal } from './components/AddEditToolModal';
import { DataBackupModal } from './components/DataBackupModal';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';
import { AITool } from './types';
import { Sparkles, Wrench, SearchX, Plus } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { 
    activeTab, 
    filteredTools, 
    searchQuery, 
    setSearchQuery,
    selectedCategory,
    pricingFilter 
  } = useApp();

  const [isAddToolOpen, setIsAddToolOpen] = useState(false);
  const [isBackupOpen, setIsBackupOpen] = useState(false);
  const [toolToEdit, setToolToEdit] = useState<AITool | null>(null);

  const handleOpenAddTool = () => {
    setToolToEdit(null);
    setIsAddToolOpen(true);
  };

  const handleEditTool = (tool: AITool) => {
    setToolToEdit(tool);
    setIsAddToolOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#070b16] text-slate-100 selection:bg-blue-600 selection:text-white font-sans antialiased" dir="rtl">
      
      {/* Top Navigation */}
      <Header 
        onOpenAddTool={handleOpenAddTool}
        onOpenBackup={() => setIsBackupOpen(true)}
      />

      {/* Hero Section */}
      <HeroSection />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Adaptive Google AdMob Banner Placeholder (Strategic slot below Hero) */}
        <AdMobPlaceholder type="banner" />

        {/* Tab 1: Tools Directory View */}
        {activeTab === 'tools' && (
          <section className="space-y-8">
            {/* Category and Pricing Filter Bar */}
            <CategoryFilter />

            {/* Tools Grid */}
            {filteredTools.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredTools.map((tool, index) => (
                  <React.Fragment key={tool.id}>
                    <ToolCard tool={tool} onEdit={handleEditTool} />
                    {/* Insert native AdMob card between tools around position 4 */}
                    {index === 3 && (
                      <div className="md:col-span-1">
                        <AdMobPlaceholder type="native" />
                      </div>
                    )}
                  </React.Fragment>
                ))}
              </div>
            ) : (
              /* Empty State */
              <div className="text-center py-20 px-4 rounded-3xl bg-[#0a1020] border border-slate-800">
                <SearchX className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">
                  لم يتم العثور على أي أداة تطابق معاييرك
                </h3>
                <p className="text-sm text-slate-400 max-w-md mx-auto mb-6">
                  جرب تغيير كلمات البحث أو إعادة ضبط فلاتر الأقسام والتسعير، أو أضف الأداة بنفسك إلى دليلك.
                </p>
                <div className="flex flex-wrap items-center justify-center gap-3">
                  <button
                    onClick={() => {
                      setSearchQuery('');
                    }}
                    className="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors cursor-pointer"
                  >
                    مسح كلمات البحث
                  </button>
                  <button
                    onClick={handleOpenAddTool}
                    className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-blue-600 hover:bg-blue-500 text-white transition-colors cursor-pointer shadow-md shadow-blue-900/30"
                  >
                    <Plus className="w-4 h-4" />
                    <span>أضف الأداة يدوياً</span>
                  </button>
                </div>
              </div>
            )}
          </section>
        )}

        {/* Tab 2: Prompts Library View */}
        {activeTab === 'prompts' && <PromptsView />}

        {/* Tab 3: Favorites View */}
        {activeTab === 'favorites' && <FavoritesView />}

        {/* Tab 4: About View */}
        {activeTab === 'about' && <AboutView />}

      </main>

      {/* Global Modals & Notifications */}
      <ToolDetailModal />
      
      <AddEditToolModal 
        isOpen={isAddToolOpen} 
        onClose={() => {
          setIsAddToolOpen(false);
          setToolToEdit(null);
        }}
        toolToEdit={toolToEdit}
      />

      <DataBackupModal 
        isOpen={isBackupOpen} 
        onClose={() => setIsBackupOpen(false)} 
      />

      <Toast />

      {/* Footer */}
      <Footer />

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
