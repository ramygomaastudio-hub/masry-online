export type AICategoryId =
  | 'image'
  | 'video'
  | 'music'
  | 'audio'
  | 'writing'
  | 'translation'
  | 'code'
  | 'chat';

export type PricingModel = 'free' | 'freemium' | 'trial' | 'paid';

export interface AICategoryMeta {
  id: AICategoryId;
  name: string;
  nameEn: string;
  description: string;
  iconName: string;
  color: string; // Tailwind gradient / border color
  badgeColor: string;
}

export interface AITool {
  id: string;
  name: string;
  arabicName: string;
  category: AICategoryId;
  description: string;
  url: string; // Real, official URL
  pricing: PricingModel;
  pricingNote?: string; // e.g. "خطة مجانية يومية مجددة"
  tags: string[];
  rating: number; // e.g. 4.9
  reviewCount: number;
  tipsForArabs: string; // Valuable advice for Egyptian & Arab users
  company: string;
  badge?: string; // e.g. 'الأقوى في الصور', 'يدعم المصرية', 'مجاني بالكامل'
  arabicSupport: 'كامل' | 'جيد جداً' | 'متوسط' | 'إنجليزية ومترجم';
  isVerified: boolean;
  isCustom?: boolean;
  notes?: string;
}

export type PromptCategoryId =
  | 'writing'
  | 'images'
  | 'video'
  | 'music'
  | 'code'
  | 'marketing'
  | 'study'
  | 'business';

export interface AIPrompt {
  id: string;
  title: string;
  category: PromptCategoryId;
  recommendedTool: string;
  promptText: string;
  explanation: string;
  variables: string[]; // e.g. ['[اسم المنتج]', '[الجمهور المستهدف]']
  tags: string[];
  difficulty: 'مبتدئ' | 'متوسط' | 'متقدم';
  isCustom?: boolean;
}

export interface AdMobConfig {
  enabled: boolean;
  appId: string;
  bannerUnitId: string;
  interstitialUnitId: string;
  nativeUnitId: string;
}
